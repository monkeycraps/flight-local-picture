<?php
class TestClass {
    public $name;

    public function TestClass($name = ''){
        $this->name = $name;
    }
}