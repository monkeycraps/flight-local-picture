
<h1>2013年会 - 美地农庄</h1>
<?php 
use RedBean_Facade as R;
$sql = 'select path from directory group by path';
$list = R::getAll($sql);
?>
<ul>
	<?php foreach( $list as $one ){ ?>
		<li><a href='/image/<?= $one['path'] ?>' ><?= $one['path'] ?></a></li>
	<?php }?>  
</ul>