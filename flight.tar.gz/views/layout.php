<!DOCTYPE html>
<html>
	<head>
		<title><?php echo $title; ?></title>
		<link rel="stylesheet" href="/bower_components/bootstrap/dist/css/bootstrap.css">
		<link rel="stylesheet" href="/bower_components/blueimp-gallery/css/blueimp-gallery.min.css">

		<script src='/bower_components/jquery/jquery.js'></script>
		<script src='/bower_components/bootstrap/dist/js/bootstrap.js'></script>
		<script src='/bower_components/blueimp-gallery/js/blueimp-gallery.js'></script>
	</head>
	<body>
		<?php echo $header_content; ?>
		<div class='container'>
			<?php echo $body_content; ?>
		</div>
		<?php echo $footer_content; ?>
	</body>
</html>